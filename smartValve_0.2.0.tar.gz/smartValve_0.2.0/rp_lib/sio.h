/*********************************************************************
    sio.h (Rev 1.0)

    SwitchBox Low Level Interface Module

    Copyright(C) 2020-2023  Memorylab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

#ifndef __SIO_H__
#define __SIO_H__

#ifdef __cplusplus
extern "C" {
#endif


/// ------------------------------------------------------------------
/// Common Interface Function
/// ------------------------------------------------------------------
SWBOX*  SIO_Init();
int     SIO_SetDebugMode(int bDebug);

int     SIO_LoadDefaultDeviceType();
int     SIO_LoadDefaultRule(char* pFileName);
int     SIO_LoadLiveSwitchRule(int iDevID, int iType, int iTime, int* iaTime, int iError);
int     SIO_LoadLiveSensorRule(int iDevID, int iLoLimit, int iHiLimit);

int     SIO_UpdateSwitchRule(int bTest);
char*   SIO_WriteSwitchAll();
int     SIO_WriteSwitch(int iIndex, int bOn);
int     SIO_UpdateSensor(SEN* pSEN, int iValue);

int     SIO_CheckAlarmAll(int bTest);
int     SIO_CheckAlarm(char** rpAlarmType, char** rpMessage);

int     SIO_ReadCOM();
int     SIO_WriteCOM();

int     SIO_ReadModbus(int bDebug, char* pBuffer, int iBuffer, char* pLog);
int     SIO_WriteModbus(int bDebug, char* pBuffer, int iBuffer, char* pLog);
int     SIO_ReadLTE(int bDebug, char* pBuffer, int iBuffer, char* pLog);
int     SIO_WriteLTE(int bDebug, char* pBuffer, int iBuffer, char* pLog);

int     SIO_ReadFIFO(int hFIFO, char* pBuffer);
int     SIO_WriteFIFO(int hFIFO, char* pBuffer, int iLength);


/// ------------------------------------------------------------------
/// Extended Interface Function
/// ------------------------------------------------------------------
char*   SIO_WriteLED();
char*   SIO_ReadButton();

char*   SIO_InitAValve();
char*   SIO_WriteAValve();
char*   SIO_ReadAValve();

char*   SIO_WriteDValve();
char*   SIO_ReadDValve();

char*   SIO_WriteCompressor();
char*   SIO_WriteAirCleaner();

char*   SIO_ReadPressure();

#ifdef __cplusplus
}
#endif

#endif

