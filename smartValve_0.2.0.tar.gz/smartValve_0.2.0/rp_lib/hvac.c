/*********************************************************************
    HVAC.c (Rev 0.90)

    HVAC Processing Module

    Copyright(C) 2022  MemoryLab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

#include <global.h>
#include "local.h"
#ifdef RASPBIAN
#else
#endif
#include "crc.h"
#include "sw_type.h"
#include "sio.h"
#include "hvac.h"


// -------------------------------------------------------------------
//  Main Memory
// -------------------------------------------------------------------
static  SWBOX*  pMM;


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     HVAC_Init(void* p)
{
    pMM = (SWBOX*)p;

    CRC_InitPoly(16, 0x80050000, 16);   // Modbus CRC
}


#define MODBUS_DEVADDR      1
#define MODBUS_REGREAD      3
#define MODBUS_REGWRITE     6
#define MODBUS_REGWRITES    16
#define IU                  0
/// ------------------------------------------------------------------
/// Interface Function
/// 01 03 00 32 00 04 e5 c6
/// ------------------------------------------------------------------
int     HVAC_Open()
{
    char    sMODBUS[100];
    int     iCRC;
    int     bDebug = TRUE;

    sMODBUS[0] = MODBUS_DEVADDR;
    sMODBUS[1] = MODBUS_REGREAD;
    sMODBUS[2] = 0;
    sMODBUS[3] = 0;             // 50 + (IU * 50) + 0;
    sMODBUS[4] = 0;
    sMODBUS[5] = 4;

    iCRC= CRC_CalcEx(16, sMODBUS, 6, -1, TRUE, TRUE);

    sMODBUS[6] = (iCRC % 256);
    sMODBUS[7] = (iCRC / 256) % 256;

    SIO_ExWriteHVAC(bDebug, sMODBUS, 8);
    SIO_ExReadHVAC(bDebug, sMODBUS, 80);

    if ( (sMODBUS[0] == MODBUS_DEVADDR) && (sMODBUS[1] == MODBUS_DEVADDR) ) {
        pMM->bHVAC_Link = TRUE;
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     HVAC_Update()
{
    HVAC_SetMode(pMM->xHVAC.iCmd, pMM->xHVAC.iCmdTemp, pMM->xHVAC.iCmdFan);

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     HVAC_SetMode(int iMode, int iVal, int iFan)
{
    if ( pMM->bHVAC_Link == FALSE )     return (FALSE);

    char    sMODBUS[100];
    int     iReg = 3;
    int     iCRC;
    int     iLen;
    int     bDebug = TRUE;

    int     iR2, iR3, iR4;

    switch (iMode) {
    case HVAC_MODE_AUTO:        iR2 = 1;    iR3 = 0;    break;
    case HVAC_MODE_COOL:        iR2 = 1;    iR3 = 1;    break;
    case HVAC_MODE_DRY:         iR2 = 1;    iR3 = 2;    break;
    case HVAC_MODE_WIND:        iR2 = 1;    iR3 = 3;    break;
    case HVAC_MODE_HEAT:        iR2 = 1;    iR3 = 4;    break;

    case HVAC_MODE_STOP:
    default:                    iR2 = 0;    iR3 = 0;    break;
    }

    switch (iFan) {
    case HVAC_FAN_AUTO:         iR4 = 0;    break;
    case HVAC_FAN_LOW:          iR4 = 1;    break;
    case HVAC_FAN_MID:          iR4 = 2;    break;
    case HVAC_FAN_HIGH:         iR4 = 3;    break;
    }

    {
    iR4 = 2;
        memset(sMODBUS, 0, 32);

        sMODBUS[0] = MODBUS_DEVADDR;
        sMODBUS[1] = MODBUS_REGWRITES;
        sMODBUS[2] = 0;
        sMODBUS[3] = 50 + (IU * 50) + 2;
        sMODBUS[4] = 0;
        sMODBUS[5] = iReg;
        sMODBUS[6] = iReg * 2;          // Byte Count

        sMODBUS[7] = iR2 / 256;
        sMODBUS[8] = iR2 % 256;
        sMODBUS[9] = iR3 / 256;
        sMODBUS[10] = iR3 % 256;
        sMODBUS[11] = iR4 / 256;
        sMODBUS[12] = iR4 % 256;

        sMODBUS[19] = iVal / 256;
        sMODBUS[20] = iVal % 256;

        iLen = 13;

        /*
        sMODBUS[0] = MODBUS_DEVADDR;
        sMODBUS[1] = MODBUS_REGWRITE;
        sMODBUS[2] = 0;
        sMODBUS[3] = 50 + (IU * 50) + 4;
        sMODBUS[4] = iR4 / 256;
        sMODBUS[5] = iR4 % 256;
        iLen = 6;
        */

        iCRC= CRC_CalcEx(16, sMODBUS, iLen, -1, TRUE, TRUE);

        sMODBUS[iLen++] = (iCRC % 256);
        sMODBUS[iLen++] = (iCRC / 256) % 256;

        SIO_ExWriteHVAC(bDebug, sMODBUS, iLen);
        usleep(1000 * 1000);
        usleep(1000 * 1000);
        usleep(1000 * 1000);
        SIO_ExReadHVAC(bDebug, sMODBUS, 80);
    }

        usleep(1000 * 1000);
        usleep(1000 * 1000);
        usleep(1000 * 1000);
    {
        sMODBUS[0] = MODBUS_DEVADDR;
        sMODBUS[1] = MODBUS_REGREAD;
        sMODBUS[2] = 0;
        sMODBUS[3] = 50 + (IU * 50) + 4;
        sMODBUS[4] = 0;
        sMODBUS[5] = 1;

        iCRC= CRC_CalcEx(16, sMODBUS, 6, -1, TRUE, TRUE);

        sMODBUS[6] = (iCRC % 256);
        sMODBUS[7] = (iCRC / 256) % 256;

        SIO_ExWriteHVAC(bDebug, sMODBUS, 8);
        usleep(100 * 1000);
        SIO_ExReadHVAC(bDebug, sMODBUS, 3 + 1 * 2 + 2);
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     HVAC_GetMode(int* riRun, int* riMode, int* riVal, int* riFan)
{
    if ( pMM->bHVAC_Link == FALSE )     return (FALSE);

    char    sMODBUS[100];
    int     iReg = 10;
    int     iCRC;
    int     bDebug = TRUE;

    UCHAR*  pSeek;
    int     iR2, iR3, iR4, iR8, iR9;

    {
        sMODBUS[0] = MODBUS_DEVADDR;
        sMODBUS[1] = MODBUS_REGREAD;
        sMODBUS[2] = 0;
        sMODBUS[3] = 50 + (IU * 50) + 0;
        sMODBUS[4] = 0;
        sMODBUS[5] = iReg;

        iCRC= CRC_CalcEx(16, sMODBUS, 6, -1, TRUE, TRUE);

        sMODBUS[6] = (iCRC % 256);
        sMODBUS[7] = (iCRC / 256) % 256;

        SIO_ExWriteHVAC(bDebug, sMODBUS, 8);
        usleep(100 * 1000);
        SIO_ExReadHVAC(bDebug, sMODBUS, 3 + iReg * 2 + 2);
    }

    pSeek = (UCHAR*)sMODBUS + 3;

    if ( riRun )    *riRun  = pSeek[4]  * 256 + pSeek[5];
    if ( riMode )   *riMode = pSeek[6]  * 256 + pSeek[7];
    if ( riFan  )   *riFan  = pSeek[8]  * 256 + pSeek[9];
    if ( riVal  )   *riVal  = pSeek[18] * 256 + pSeek[19];

    return (TRUE);
}
