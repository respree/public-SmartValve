
/*********************************************************************
    fifo.c  (Rev 0.80)

    FIFO interface

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

#include "global.h"
#include "local.h"
#include "json.h"
#include "sw_type.h"
#include "nio.h"
#include "sio.h"
#include "nats.h"
#include "payload.h"


// -------------------------------------------------------------------
//  Type Definition
// -------------------------------------------------------------------
extern  SWBOX*  pMM;


// -------------------------------------------------------------------
//  Global Definition
// -------------------------------------------------------------------
#define FILE_WPA_REAL       "/etc/wpa_supplicant/wpa_supplicant.conf"
#define FILE_WPA_TEST       "./ble/wpa_supplicant.conf"


// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
int     FIFO_Process()
{
    char    sHead[1024];
    char    sData[1024];
    int     iData;
    char*   pCmd;
    FILE*   f;

    char*   pType;
    char*   pData;
    char*   pError;

    int     iType;
    int     iTime;
    int     iaTime[300];
    int     iError;

    memset(sData, 0, 1024);

    iData = SIO_ReadFIFO(pMM->hRFIFO, sData);
// {"WIFI":{"ssid":"zzzzz","passwd":"qqqqq","key_mgmt":"WPA-PSK"}}
//  strcpy(sData, "[RC][RC][RC][RE][RC]");
//  iData = strlen(sData);

    if ( iData <= 0 ) {
        return (FALSE);
    }

    if (0)
    {
        char*   pSeek;

        while (TRUE) {
            pSeek = strstr(sData, "[RC]");
            if ( pSeek == NULL )  break;

            memmove(pSeek, pSeek + 4, strlen(pSeek) + 1);
        }

        if (sData[0] == 0) {
            strcpy(sData, "[RC]");
        }
    }

    printf("++++++++++++++++++++++++++++++++++++++++\n");
    printf("[RDFIFO:%d] %s\n", iData, sData);
    printf("++++++++++++++++++++++++++++++++++++++++\n");

    if ( !strncmp(sData, "[WC]", 4) ) {
        pCmd = SP_BLE_Decode(sData + 4);
        return (TRUE);
    }

    if ( !strncmp(sData, "[RC]", 4) ) {
        SP_Encode(NACMD_PUB_STATUS, sHead, sData);
        iData = strlen(sData);
    /// SIO_WriteFIFO(pMM->hWFIFO, sData, iData);
        {
            FILE*   f = fopen("./ble/getstat.txt", "w");
            fprintf(f, sData);
            fclose(f);
        }

        return (TRUE);
    }

    if ( !strncmp(sData, "[WE]", 4) ) pCmd = SP_BLE_Decode(sData + 4);
    if ( !strncmp(sData, "[RE]", 4) ) pCmd = "GETENV";

    if ( !strncmp(pCmd, "WIFI", 4) ) {
        f = fopen(FILE_WPA_REAL, "w");

        char* p1 = SP_BLE_GetItem("ssid");
        char* p2 = SP_BLE_GetItem("passwd");
        char* p3 = SP_BLE_GetItem("key_mgmt");

        fprintf( f, "\
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\n\
update_config=1\n\
country=KR\n\
\n\
network={\n\
\tssid=\"%s\"\n\
\tscan_ssid=1\n\
\tpsk=\"%s\"\n\
\tkey_mgmt=%s\n\
}",
                SP_BLE_GetItem("ssid"),
                SP_BLE_GetItem("passwd"),
                SP_BLE_GetItem("key_mgmt") );

        fclose(f);
        NIO_Reboot("1234qwer");

        return (TRUE);
    }

    if ( (!strncmp(pCmd, "GETENV", 6)) && (SP_GetNetworkType() == NETWORK_WIFI) ) {
        char*   pValveType = (pMM->xCI.iValveType == 0) ? "control" : "onoff";

        sprintf(sData,
                "{'name':'%s',"
                "'network':{'type':'WIFI',"
                           "'data':{'ssid':'%s','macid':'%s'}},"
                "'nats':'%s','valvetype':'%s'}",

                pMM->xCI.sModelName,

                NIO_GetSSID("wlan0"),
                pMM->xCI.sControllerMacID,

                pMM->xCI.sServerURL,
                pValveType );

    }

    if ( (!strncmp(pCmd, "GETENV", 6)) && (SP_GetNetworkType() == NETWORK_LTE) ) {
        char*   pValveType = (pMM->xCI.iValveType == 0) ? "control" : "onoff";

        NIO_GetNetwork("usb0");

        sprintf(sData,
                "{'name':'%s',"
                "'network':{'type':'LTE',"
                           "'data':{'ip':'%s','netmask':'%s','gateway':'%s'}},"
                "'nats':'%s','valvetype':'%s'}",

                pMM->xCI.sModelName,

                NIO_GetNetworkIP(),
                NIO_GetNetworkMask(),
                NIO_GetGatewayIP(),

                pMM->xCI.sServerURL,
                pValveType );
    }

    for ( int i = 0 ; i < strlen(sData) ; i++ ) {
        if ( sData[i] == '\'' )         sData[i] = '\"';
    }

    printf("----------------------------------------\n");
    printf("[WRFIFO:%d] %s\n", iData, sData);
    printf("----------------------------------------\n");

    iData = strlen(sData);
/// SIO_WriteFIFO(pMM->hWFIFO, sData, iData);
    {
        FILE*   f = fopen("./ble/getenv.txt", "w");
        fprintf(f, sData);
        fclose(f);
    }

    return (TRUE);
}


// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
int     FIFO_InitFile()
{
    char*   pValveType = (pMM->xCI.iValveType == 0) ? "control" : "onoff";

    char    sData[1024];
    int     iData;

    if ( (SP_GetNetworkType() == NETWORK_WIFI) ) {
        char*   pValveType = (pMM->xCI.iValveType == 0) ? "control" : "onoff";

        sprintf(sData,
                "{'name':'%s',"
                "'network':{'type':'WIFI',"
                           "'data':{'ssid':'%s','macid':'%s'}},"
                "'nats':'%s','valvetype':'%s'}",

                pMM->xCI.sModelName,

                NIO_GetSSID("wlan0"),
                pMM->xCI.sControllerMacID,

                pMM->xCI.sServerURL,
                pValveType );

    }

    if ( (SP_GetNetworkType() == NETWORK_LTE) ) {
        char*   pValveType = (pMM->xCI.iValveType == 0) ? "control" : "onoff";

        NIO_GetNetwork("usb0");

        sprintf(sData,
                "{'name':'%s',"
                "'network':{'type':'LTE',"
                           "'data':{'ip':'%s','netmask':'%s','gateway':'%s'}},"
                "'nats':'%s','valvetype':'%s'}",

                pMM->xCI.sModelName,

                NIO_GetNetworkIP(),
                NIO_GetNetworkMask(),
                NIO_GetGatewayIP(),

                pMM->xCI.sServerURL,
                pValveType );
    }

    for ( int i = 0 ; i < strlen(sData) ; i++ ) {
        if ( sData[i] == '\'' )         sData[i] = '\"';
    }

    iData = strlen(sData);
/// SIO_WriteFIFO(pMM->hWFIFO, sData, iData);
    {
        FILE*   f = fopen("./ble/getenv.txt", "w");
        fprintf(f, sData);
        fclose(f);
    }

    return (TRUE);
}
