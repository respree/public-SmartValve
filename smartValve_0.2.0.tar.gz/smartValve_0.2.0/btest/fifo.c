
/*********************************************************************
    fifo.c  (Rev 0.80)

    FIFO interface

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

#include <global.h>
#include "local.h"
#include "json.h"
#include "sw_type.h"
#include "hal.h"
#include "nio.h"
#include "sio.h"
#include "protocol.h"


// -------------------------------------------------------------------
//  Type Definition
// -------------------------------------------------------------------
extern  SWBOX*  pMM;


// -------------------------------------------------------------------
//  Global Definition
// -------------------------------------------------------------------
#define FILE_WPA            "./ble/wpa_supplicant.conf"

#define BLECMD_WIFI_IP      10


// -------------------------------------------------------------------
//  Interface Function
// -------------------------------------------------------------------
int     FIFO_Process()
{
    char    sBuffer[1024];
    int     iBuffer;
    char*   pCmd;
    int     iCmd;
    FILE*   f;

    char*   pType;
    char*   pData;
    char*   pError;

    int     iType;
    int     iTime;
    int     iaTime[300];
    int     iError;

    memset(sBuffer, 0, 1024);

    iBuffer = SIO_ReadFIFO(pMM->hRFIFO, sBuffer);
/// strcpy(sBuffer, "{\"ssid\":\"aaaa\",\"passwd\":\"bbbb\",\"key_mgmt\":\"NONE\"}");
// {"WIFI":{"ssid":"zzzzz","passwd":"qqqqq","key_mgmt":"WPA-PSK"}}

    iBuffer = strlen(sBuffer);

    if ( iBuffer <= 0 ) {
    /// printf("FIFOEMPTY\n");
        return (FALSE);
    }

    printf("++++++++++++++++++++++++++++++++++++++++\n");
    printf("[FIFO:%d] %s\n", iBuffer, sBuffer);
    printf("++++++++++++++++++++++++++++++++++++++++\n");

    pCmd = SP_BLE_Decode(sBuffer + 4);  // [WS]{data}

printf(">>> %s\n", pCmd);
/// if ( !strncmp(pCmd, "switch", 6) )  // Processed in Decode
/// if ( !strncmp(pCmd, "sensor", 6) )  // Processed in Decode
    if ( !strncmp(pCmd, "WIFI", 4) )    iCmd = BLECMD_WIFI_IP;

    switch (iCmd) {
    case BLECMD_WIFI_IP :
        f = fopen(FILE_WPA, "w");

        fprintf( f, "\
ctrl_interface=DIR=/var/run/wap_supplicant GROUP=netdev\
update_config=1\n\
country=KR\n\
\n\
network=\n\
    ssid=\"%s\"\n\
    scan_ssid=1\n\
    psk=\"%s\"\n\
    key_mgmt=%s\n\
}",
                SP_BLE_GetItem("ssid"),
                SP_BLE_GetItem("passwd"),
                SP_BLE_GetItem("key_mgmt") );

        fclose(f);
    //  NIO_Reboot("qwer1234");
    }

    return (TRUE);
}
