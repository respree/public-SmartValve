/*********************************************************************
    nio.h (Rev 0.90)

    SwitchBox Network Module

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

#ifndef __NIO_H__
#define __NIO_H__

#ifdef __cplusplus
extern "C" {
#endif

char*   NIO_GetVersion();
char*   NIO_GetSerial();

char*   NIO_GetNetwork(char* pIfName);
char*   NIO_GetNetworkIP();
char*   NIO_GetNetworkMask();
char*   NIO_GetGatewayIP();

char*   NIO_GetMacAddress(char* pIfName);
char*   NIO_GetSSID(char* pIfName);

int     NIO_UpdateIP(char* pIP);
void    NIO_Reboot(char* pPass);

#ifdef __cplusplus
}
#endif

#endif

