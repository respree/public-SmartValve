#define LOCAL

#include <fcntl.h>

#include <ifaddrs.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/reboot.h>


#ifdef WIN32
#define delay_ms(a)         Sleep(a * 1000)
#endif
#ifdef RASPBIAN
#define delay_ms(a)         usleep(a * 1000);
#endif
#ifdef ARDUINO_ESP32
#define delay_ms(a)         delay(a);
#endif


#ifdef RASPBIAN
#define NIO_IF_NAME         "wlan0"
#define NIO_REBOOT_SH       "/home/pi/smartValve/bb.sh"
#else
#define NIO_IF_NAME         "ens33"
#define NIO_REBOOT_SH       "/home/stellar/swbox/bb.sh"
#endif


#define NIO_DEFAULT_IP      "192.168.10.220"
#define NIO_DEFAULT_MASK    "255.255.255.0"
#define NIO_DEFAULT_GW      "192.168.10.1"


#define SWBOX_VERSION       "0.2.0"
#define SWBOX_SERIAL        "1000_3000_1225"

#define NO_USE_SWBOX
