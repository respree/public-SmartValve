/*********************************************************************
    hal_type.h (Rev 1.00)

    HAL Pinmap

    Copyright(C) Memorylab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

// -------------------------------------------------------------------
//	Basic Type Definition
// -------------------------------------------------------------------
#define PIN_1_3V
#define PIN_3_SDA
#define PIN_5_SCL
#define PIN_7					4
#define PIN_9_GND
#define PIN_11					17
#define PIN_13					27
#define PIN_15					22
#define PIN_17_3V
#define PIN_19_SPI_MOSI
#define PIN_19_GPIO				10
#define PIN_21_SPI_MISO
#define PIN_23_SPI_CLK
#define PIN_23_GPIO				11
#define PIN_25_GND
#define PIN_27_ID_SD
#define PIN_29					5
#define PIN_31					6
#define PIN_33					13
#define PIN_35					19
#define PIN_37					26
#define PIN_39_GND

#define PIN_2_5V
#define PIN_4_5V
#define PIN_6_GND
#define PIN_8_TXD0
#define PIN_10_RXD0
#define PIN_12					18
#define PIN_14_GND
#define PIN_16					23
#define PIN_18					24
#define PIN_20_GND
#define PIN_22					25
#define PIN_24_SPI_CS0
#define PIN_26_SPI_CS1
#define PIN_26_GPIO				7
#define PIN_28_ID_SC

#define PIN_30_GND
#define PIN_32					12
#define PIN_34_GND
#define PIN_36					16
#define PIN_38					20
#define PIN_40					21


#define GPIO_4					4
#define GPIO_5					5
#define GPIO_6					6
#define GPIO_7					PIN_26_GPIO
#define GPIO_16					16
#define GPIO_17					17
#define GPIO_18					18
#define GPIO_19					19
#define GPIO_20					20
#define GPIO_21					21
#define GPIO_22					22
#define GPIO_23					23
#define GPIO_24					24
#define GPIO_25					25
#define GPIO_26					26
#define GPIO_27					27

#define I2C_SCL					PIN_5_SCL
#define I2C_SDA					PIN_3_SDA

#define SPI_CE0_N				PIN_24_SPI_CS0
#define SPI_CE1_N				PIN_26_SPI_CS1
#define SPI_SCLK				PIN_23_SPI_CLK
#define SPI_MISO				PIN_21_SPI_MISO
#define SPI_MOSI				PIN_19_SPI_MOSI

#define DO_SW_RELAY1			PIN_11
#define DO_SW_RELAY2			PIN_13
#define DO_SW_RELAY3			PIN_15
#define DO_SW_RELAY4			PIN_29
#define DO_SW_RELAY5			PIN_31
#define DO_SW_RELAY6			PIN_33
#define DO_SW_RELAY7			PIN_35
#define DO_SW_RELAY8			PIN_37


// -------------------------------------------------------------------
//	Application Mapping for SmartFarm
// -------------------------------------------------------------------
#define DO_AC_RELAY1			PIN_11
#define DO_AC_RELAY2			PIN_13
#define DO_AC_RELAY3			PIN_15
#define DO_AC_RELAY4			PIN_29
#define DO_AC_RELAY5			PIN_31
#define DO_AC_RELAY6			PIN_33
#define DO_AC_RELAY7			PIN_35
#define DO_AC_RELAY8			PIN_37

#define DO_DC_RELAY1			PIN_12
#define DO_DC_RELAY2			PIN_16
#define DO_DC_RELAY3			PIN_18
#define DO_DC_RELAY4			PIN_22
#define DO_DC_RELAY5			PIN_32
#define DO_DC_RELAY6			PIN_36
#define DO_DC_RELAY7			PIN_38
#define DO_DC_RELAY8			PIN_40


// -------------------------------------------------------------------
//	Application Mapping for SmartVALVE
// -------------------------------------------------------------------
#define SVC_PROXIMITY0			GPIO_16
#define SVC_PROXIMITY1			GPIO_17

#define SVC_SOLENOID0			GPIO_18
#define SVC_SOLENOID1			GPIO_19
#define SVC_SOLENOID2			GPIO_20
#define SVC_POWER_RELAY0		GPIO_21
#define SVC_POWER_RELAY1		GPIO_22

#define SVC_LTE_FL_MODE			GPIO_23
#define SVC_LTE_MODULE_ON		GPIO_24
#define SVC_DAC_nERR			GPIO_25
#define SVC_ADC_READY			GPIO_26

#define SVC_TEST_LED			GPIO_27
#define SVC_TEST_PUSH_SW		GPIO_6
#define SVC_TEST_SLIDE_SW		GPIO_7

#define SVC_UART_SEL0			GPIO_4
#define SVC_UART_SEL1			GPIO_5


// -------------------------------------------------------------------
//	Application Mapping for SmartCar
// -------------------------------------------------------------------
#define CAR_LED_EN0				PIN_19_GPIO
#define CAR_LED_EN1				PIN_23_GPIO

#define CAR_LED0				PIN_38
#define CAR_LED1				PIN_40
#define CAR_LED2				PIN_15
#define CAR_LED3				PIN_16

#define CAR_SW0					PIN_18
#define CAR_SW1					PIN_22
#define CAR_SW2					PIN_37
#define CAR_SW3					PIN_13

/*
#define CAR_MOTOR_ENABLE		PIN_23
#define CAR_MOTOR_PWM1			PIN_33
#define CAR_MOTOR_PWM0			PIN_32
*/
#define CAR_MOTOR_PM			PIN_33
#define CAR_MOTOR_SM			PIN_32

#define CAR_IR0_SENSE			PIN_36
#define CAR_IR1_SENSE			PIN_11
#define CAR_IR2_SENSE			PIN_12
#define CAR_IR3_SENSE			PIN_35

#define CAR_US_TRIG			    PIN_31
#define CAR_US_FF_ECHO			PIN_29
#define CAR_US_RR_ECHO			PIN_26
