/*********************************************************************
    sio_ex.c (Rev 0.90)

    SwitchBox Extended Processing Module

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

#include "global.h"
#include "local.h"
#include "hal_type.h"
#include "hal.h"
#include "sw_type.h"
#include "sio.h"
#include "nio.h"


// -------------------------------------------------------------------
//  Main Memory
// -------------------------------------------------------------------
extern  SWBOX*  pMM;
extern  int     m_bDebug;


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   sio_ExWriteGPIO(SW* pSW, int iPort, int bNEG)
{
    int     iOut    = pSW->iOutVal;
    char    cLOG    = ' ';

    iOut = (bNEG == TRUE) ? 1 - iOut : iOut;
    HAL_WriteGPIO(iPort, iOut);

    if (bNEG == FALSE)      cLOG = (iOut == TRUE)  ? 'O' : '_';
    if (bNEG == TRUE)       cLOG = (iOut == FALSE) ? 'N' : '.';

    sprintf(pSW->sLog, "%c", cLOG);

    return(pSW->sLog);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   sio_ExReadGPIO(SEN* pSEN, int iPort, int bNEG)
{
    int     iRead;
    char    cLOG    = ' ';

    iRead = HAL_ReadGPIO(iPort);
    SIO_UpdateSensor(pSEN, iRead);

    if (bNEG == FALSE)      cLOG = (iRead == TRUE)  ? 'O' : '_';
    if (bNEG == TRUE)       cLOG = (iRead == FALSE) ? 'N' : '.';

    sprintf(pSEN->sLog, "%c", cLOG);

    return(pSEN->sLog);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   SIO_WriteLED()
{
    SW*     pSW = &(pMM->xSW[DEVID_SW_LED]);

    return ( sio_ExWriteGPIO(pSW, SVC_TEST_LED, FALSE) );
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   SIO_ReadButton()
{
    SEN*    pSEN = &(pMM->xSEN[DEVID_SEN_BTN]);

    return ( sio_ExReadGPIO(pSEN, SVC_TEST_PUSH_SW, TRUE) );
}


/// ------------------------------------------------------------------
/// Interface Definition : SPI
/// ------------------------------------------------------------------
#define DACREG_XREF_REG         0x01
#define DACREG_NOP              0x02
#define DACREG_WR_MODE          0x03
#define DACREG_DACCODE          0x04
#define DACREG_ERR_CONFIG       0x05
#define DACREG_RESET            0x08
#define DACREG_STATUS           0x09

#define DAC_CURRENT_4mA         0x2AAA
#define DAC_CURRENT_20mA        0xD555
#define DDC_CURRENT_diff        (DAC_CURRENT_20mA - DAC_CURRENT_4mA)

#define ADC_CURRENT_4mA         6400
#define ADC_CURRENT_20mA        32000
#define ADC_CURRENT_diff        (ADC_CURRENT_20mA - ADC_CURRENT_4mA)


/// ------------------------------------------------------------------
/// Interface Function : SPI
/// ------------------------------------------------------------------
void    sio_DAC_WriteReg(int iSPI_Addr, int iSPI_Data)
{
    char sBuffer[3];

    sBuffer[0] = iSPI_Addr;                     // Register Address
    sBuffer[1] = ( iSPI_Data >> 8 ) & 0xFF;     // Top 8Bit
    sBuffer[2] = iSPI_Data & 0xFF;              // Bottom 8Bit

    HAL_WriteSPI(sBuffer, 3);

    delay_ms(10);
}


/// ------------------------------------------------------------------
/// Interface Function : SPI
/// ------------------------------------------------------------------
int     sio_DAC_ReadReg(int iSPI_Addr)
{
    char sBuffer[3];

    sBuffer[0] = 0x80 | iSPI_Addr;              // Register Address
    sBuffer[1] = 0x00;
    sBuffer[2] = 0x00;

    HAL_ReadSPI(sBuffer, 3);
    HAL_ReadSPI(sBuffer, 3);

    delay_ms(10);

    return ( sBuffer[1] * 0x100 + sBuffer[2] );
}


/// ------------------------------------------------------------------
/// Interface Function : SPI
/// ------------------------------------------------------------------
char*   SIO_InitAValve()
{
    SW*     pSW     = &(pMM->xSW[DEVID_SW_AV]);
    char*   pLog    = pSW->sLog;
    int     iRet;

    sio_DAC_WriteReg(DACREG_RESET,      0xC33C);
    sio_DAC_WriteReg(DACREG_ERR_CONFIG, 0x035F);
    sio_DAC_WriteReg(DACREG_XREF_REG,   0x00FF);

    iRet = sio_DAC_ReadReg(DACREG_STATUS);

    sprintf(pLog, "DAC Init %d", iRet);

    return (pLog);
}


/// ------------------------------------------------------------------
/// Interface Function : SPI
/// ------------------------------------------------------------------
char*   SIO_WriteAValve()
{
    SW*     pSW     = &(pMM->xSW[DEVID_SW_AV]);
    char*   pLog    = pSW->sLog;
    int     iOut    = pSW->iOutVal;
    int     iCurrent;
    int     iRet;

    iCurrent = DDC_CURRENT_diff * iOut / 100 + DAC_CURRENT_4mA;

    sio_DAC_WriteReg(DACREG_DACCODE,    iCurrent);

    iRet = sio_DAC_ReadReg(DACREG_STATUS);

    if ( pSW->iUpdateOut != iOut ) {
        pSW->iUpdateOut     = iOut;
        pSW->iFeedbackTime  = HAL_GetLocalTime() + pMM->xCI.iReactionTime;
    }

    sprintf(pLog, "%d", iOut);

    return(pLog);
}


/// ------------------------------------------------------------------
/// Interface Definition : I2C
/// ------------------------------------------------------------------
#define ADCREG_CONVERSION       0x00
#define ADCREG_CONFIG           0x01


UCHAR   cConfigValue[4][2]  = { //  OS[15], MUX[14:12], PGA[11:9],
    {0xC4, 0x83},               //  1100 0100 1000 0011
    {0xD4, 0x83},               //  1101 0100 1000 0011
    {0xE4, 0x83},               //  1110 0100 1000 0011
    {0xF4, 0x83},               //  1111 0100 1000 0011
};


/// ------------------------------------------------------------------
/// Interface Function : I2C
/// ------------------------------------------------------------------
int     sio_ADC_ReadReg(char cI2C_Addr)
{
    char    sBuffer[2];

    HAL_ReadI2C(&cI2C_Addr, 1, sBuffer, 2);

    return ( sBuffer[0] * 0x100 + sBuffer[1] );
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   SIO_ReadAValve()
{
    SW*     pSW     = &(pMM->xSW[DEVID_SW_AV]);
    SEN*    pSEN    = &(pMM->xSEN[DEVID_SEN_AV]);
    char*   pLog    = pSEN->sLog;
    int     iStat   = pSEN->iOutVal;

    char    cLog;
    char    cError;

    {
        char    sREG[1];
        char    sI2C[2];
        int     iOut;

    //  HAL_ReadGPIO(SVC_ADC_READY);

        sREG[0] = ADCREG_CONFIG;
        sI2C[0] = cConfigValue[0][0];
        sI2C[1] = cConfigValue[0][1];

        HAL_WriteI2C(sREG, 1, sI2C, 2);

    /// delay_ms(1000);
        delay_ms(100);

        {
            sREG[0] = ADCREG_CONFIG;
            HAL_ReadI2C(sREG, 1, sI2C, 2);

            iOut = sI2C[0] * 0x100 + sI2C[1];

        /// if ( iOut & 0x8000 == 0 )       BUSY;
        }

        {
            sREG[0] = ADCREG_CONVERSION;
            HAL_ReadI2C(sREG, 1, sI2C, 2);

            memset(pSEN->sRaw, 0, RAW_LEN);
            memcpy(pSEN->sRaw, sI2C, 2);

            iOut = sI2C[0] * 256 + sI2C[1];

            iOut = 100 * 100 * (iOut - ADC_CURRENT_4mA) / ADC_CURRENT_diff;

            if ( iOut <     0 )     iOut = 99999;   // Error Value
            if ( iOut > 13000 )     iOut = 13300;   // Error Value
        }

        iStat = iOut;
    }

    SIO_UpdateSensor(pSEN, iStat);

    pSEN->bFeedbackError = FALSE;
    if ( iStat > (pSEN->iOutVal * 100 + pSW->iErrorRate) )  pSEN->bFeedbackError = TRUE;
    if ( iStat < (pSEN->iOutVal * 100 - pSW->iErrorRate) )  pSEN->bFeedbackError = TRUE;

    if ( HAL_GetLocalTime() < pSW->iFeedbackTime )          pSEN->bFeedbackError = FALSE;

    cError  = (pSEN->bFeedbackError == TRUE) ? 'F' : ' ';

    sprintf(pLog, "%d.%02d%c", iStat / 100, iStat % 100, cError);

    return(pLog);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   SIO_WriteDValve()
{
    SW*     pSW     = &(pMM->xSW[DEVID_SW_DV]);

    return ( sio_ExWriteGPIO(pSW, SVC_SOLENOID0, FALSE) );
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   SIO_ReadDValve()
{
    static  char    sLog[256];
    char    cLog;
    char    cSW0;
    char    cSW1;
    char    cError;

    SEN*    pSEN    = &(pMM->xSEN[DEVID_SEN_DV]);
    int     iSW0;
    int     iSW1;
    int     iRead;
    int     iStat   = 0;

    iSW0    = HAL_ReadGPIO(SVC_PROXIMITY0);
    iSW1    = HAL_ReadGPIO(SVC_PROXIMITY1);
    iRead   = iSW0 + iSW1 * 2;

    switch (iRead) {
    case 1: iStat = 0;              break;
    case 2: iStat = 1;              break;

    case 0:
    case 3: iStat = 0;
            pSEN->bFeedbackError    = TRUE;
            pSEN->sRaw[0]           = iRead;
    }

    SIO_UpdateSensor(pSEN, iStat);

    cLog    = (iStat == TRUE)  ? 'O' : '_';
    cSW0    = (iSW0  == TRUE)  ? 'O' : '_';
    cSW1    = (iSW1  == TRUE)  ? 'O' : '_';
    cError  = (pSEN->bFeedbackError == TRUE) ? 'E' : ' ';

    sprintf(sLog, "%c%c%c", cSW0, cSW1, cError);

    return(sLog);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   SIO_WriteCompressor()
{
    SW*     pSW     = &(pMM->xSW[DEVID_SW_COMP]);
    SEN*    pSEN    = &(pMM->xSEN[DEVID_SEN_COMP]);

    if ( pSW->iActionType == ACTION_MINMAX )    // MINMAX Auto Update
    {
        if ( (pSW->R[0].iLow  * 100) < pSEN->iOutVal )  pSW->iOutVal = 1;
        if ( (pSW->R[0].iHigh * 100) > pSEN->iOutVal )  pSW->iOutVal = 0;
    }

    return ( sio_ExWriteGPIO(pSW, SVC_POWER_RELAY0, FALSE) );
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   SIO_WriteAirCleaner()
{
    SW*     pSW     = &(pMM->xSW[DEVID_SW_AIR]);

    return ( sio_ExWriteGPIO(pSW, SVC_SOLENOID1, FALSE) );
}


#define COMP_MAX_10BARG         10
/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   SIO_ReadPressure()
{
    SW*     pSW     = &(pMM->xSW[DEVID_SW_COMP]);
    SEN*    pSEN    = &(pMM->xSEN[DEVID_SEN_COMP]);
    char*   pLog    = pSEN->sLog;
    int     iStat;

    {
        char    sREG[1];
        char    sI2C[4];
        int     iOut;

        sREG[0] = ADCREG_CONFIG;
        sI2C[0] = cConfigValue[1][0];
        sI2C[1] = cConfigValue[1][1];

        HAL_WriteI2C(sREG, 1, sI2C, 2);

    /// delay_ms(1000);
        delay_ms(100);

        {
            sREG[0] = ADCREG_CONFIG;
            HAL_ReadI2C(sREG, 1, sI2C, 2);

            iOut = sI2C[0] * 0x100 + sI2C[1];

        /// if ( iOut & 0x8000 == 0 )       BUSY;
        }

        {
            sREG[0] = ADCREG_CONVERSION;
            HAL_ReadI2C(sREG, 1, sI2C, 2);

            memset(pSEN->sRaw, 0, RAW_LEN);
            memcpy(pSEN->sRaw, sI2C, 2);

            iOut = sI2C[0] * 256 + sI2C[1];

            iOut = iOut - ADC_CURRENT_4mA;
            iOut = COMP_MAX_10BARG * 100 * iOut / ADC_CURRENT_diff;

            if ( iOut <    0 )      iOut = 9999;    // Error Value
            if ( iOut > 1300 )      iOut = 1300;    // Error Value
        }

        iStat = iOut;
    }

    SIO_UpdateSensor(pSEN, iStat);

    pSEN->iOutVal = iStat;

    pSEN->bMinMaxError  = FALSE;
    {
        if ( (pSW->R[0].iMin  * 100) < iStat )  pSEN->bMinMaxError = TRUE;
        if ( (pSW->R[0].iMax  * 100) > iStat )  pSEN->bMinMaxError = TRUE;

    /// if ( (pSW->R[0].iLow  * 100) < iStat )  pSW->iOutVal = 1;
    /// if ( (pSW->R[0].iHigh * 100) > iStat )  pSW->iOutVal = 0;

        /// else Keep Status
    }

    sprintf(pLog, "%d", iStat);

    return(pLog);
}
