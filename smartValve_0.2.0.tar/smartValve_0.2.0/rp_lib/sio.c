/*********************************************************************
    sio.c (Rev 1.0)

    SwitchBox Low Level Interface Module

    Copyright(C) 2020-2023  Memorylab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

#include "global.h"
#include "local.h"
#include "hal_type.h"
#include "hal.h"
#include "sw_type.h"
#include "sio.h"
#include "nio.h"


// -------------------------------------------------------------------
//  Main Memory
// -------------------------------------------------------------------
SWBOX   xMM;
SWBOX*  pMM = &xMM;

int     m_bDebug    = FALSE;
int     m_bUART_mux = 0;

#define I2C_ID_SVCADC       0x48

#define SPI_CH0             0
#define SPI_CH1             1
#define SPI_SPEED           (50 * 1000)


#define UART_MUX_MODBUS     0
#define UART_MUX_LTE        1

#define MODBUS_COM          1
#define MODBUS_SPEED        115200
/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
SWBOX*  SIO_Init()
{
    char    cData[32];

    memset(pMM, 0, sizeof(SWBOX));

    SIO_LoadDefaultDeviceType();

    HAL_Init();

    HAL_WriteGPIO(SVC_UART_SEL0, 0);        // UART MUX selection
    HAL_WriteGPIO(SVC_UART_SEL1, 0);

    HAL_WriteGPIO(SVC_LTE_MODULE_ON, 1);
    HAL_WriteGPIO(SVC_LTE_FL_MODE,   1);    // Active Low

#ifdef RASPBIAN
    // i2cdetect -l
    // i2cdetect -y 1
    HAL_OpenI2C(NULL, I2C_ID_SVCADC);

    cData[0] = 0x17;                // ADC Conf. Byte 0001_0111
    HAL_WriteI2C(NULL, 0, cData, 1);

    HAL_OpenSPI(SPI_CH0, SPI_SPEED);

/// HAL_OpenCOM(MODBUS_COM, MODBUS_SPEED, 10);
    HAL_OpenCOM(MODBUS_COM, MODBUS_SPEED, 0);

    pMM->hRFIFO = HAL_OpenFIFO(FIFO_BLE_RD, 0);
    pMM->hWFIFO = HAL_OpenFIFO(FIFO_BLE_WR, 0);
#endif

    return (pMM);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_SetDebugMode(int bDebug)
{
    m_bDebug = bDebug;

    return (bDebug);
}


/// ------------------------------------------------------------------
/// Interface Function
/// Device Specific Initialization
/// ------------------------------------------------------------------
int     SIO_LoadDefaultDeviceType()
{
    for ( int i = 1 ; i < SW_ARRAY ; i++ ) {
        pMM->xSW[i].iDeviceType = SW_RELAY;

        if ( i == 1 )   pMM->xSW[i].iDeviceType = SW_VALVE;
    }

    for ( int i = 1 ; i < SEN_ARRAY ; i++ ) {
        pMM->xSEN[i].iDeviceType = SEN_RELAY;

        if ( i == 1 )   pMM->xSEN[i].iDeviceType = SEN_VALVE;
    }

    // Feedback device
    pMM->xSW[DEVID_SW_AV].pSEN =  &(pMM->xSEN[DEVID_SEN_AV]);
    pMM->xSW[DEVID_SW_DV].pSEN =  &(pMM->xSEN[DEVID_SEN_DV]);

    pMM->xSEN[DEVID_SEN_AV].bUseFeedBack = TRUE;
    pMM->xSEN[DEVID_SEN_DV].bUseFeedBack = TRUE;

    return (TRUE);
}


int     sio_LoadDefaultRuleLine(char* pLine);
int     sio_LoadSwitchRule(int iID, int iType, int i1, int i2, int i3, int i4);
int     sio_LoadSensorRule(int iID, int iLoLimit, int iHiLimit);
/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_LoadDefaultRule(char* pFileName)
{
    FILE*   f;
    char    sLine[256];
    char*   p;

    f = fopen(pFileName, "r");
    if ( f == NULL )            return (FALSE);

    while ( !feof(f) ) {
        p = fgets(sLine, 256, f);
        if ( p == NULL )    continue;

        sio_LoadDefaultRuleLine(sLine);
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_LoadDefaultRuleString(char* pString)
{
    char*   pLine;

    pLine = strtok(pString, "\r\n");
    while ( pLine ) {
        sio_LoadDefaultRuleLine(pLine);

        pLine = strtok(pString, "\r\n");
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     sio_LoadDefaultRuleLine(char* pLine)
{
    char*   p;

    int     iID = 0;
    int     i0  = 0;
    int     i1  = 0;
    int     i2  = 0;
    int     i3  = 0;
    int     i4  = 0;

    while (TRUE) {
        i0 = 0;
        i1 = 0;
        i2 = 0;


        p = strtok(pLine, " ,\t\n\r");
        if ( p == NULL )    break;

        if ( !strncmp(p, "SW", 2) )     iID = 10 + p[2] - '0';
        if ( !strncmp(p, "SEN", 3) )    iID = 30 + p[3] - '0';

        if ( !strncmp(p, "HVAC", 4) )   iID = 80;

        p = strtok(NULL,  " ,\t\n\r");  // description

        p = strtok(NULL,  " ,\t\n\r");
        if ( p != NULL )    i0 = atoi(p);

        p = strtok(NULL,  " ,\t\n\r");
        if ( p != NULL )    i1 = atoi(p);

        p = strtok(NULL,  " ,\t\n\r");
        if ( p != NULL )    i2 = atoi(p);

        p = strtok(NULL,  " ,\t\n\r");
        if ( p != NULL )    i3 = atoi(p);

        p = strtok(NULL,  " ,\t\n\r");
        if ( p != NULL )    i4 = atoi(p);

        if ( (iID / 10 == 1) )  sio_LoadSwitchRule(iID, i0, i1, i2, i3, i4);
        if ( (iID / 10 == 3) )  sio_LoadSensorRule(iID, i0, i1);

        break;
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     sio_LoadSwitchRule(int iID, int iType, int i1, int i2, int i3, int i4)
{
    int     iValue  = i1;
    int     iOn     = i2;
    int     iOff    = i3;

    SW*     pSW = NULL;
    RULE*   pRule = NULL;

    if ( iID == 11 )    pSW = &(pMM->xSW[1]);
    if ( iID == 12 )    pSW = &(pMM->xSW[2]);
    if ( iID == 13 )    pSW = &(pMM->xSW[3]);
    if ( iID == 14 )    pSW = &(pMM->xSW[4]);
    if ( iID == 15 )    pSW = &(pMM->xSW[5]);
    if ( iID == 16 )    pSW = &(pMM->xSW[6]);
    if ( iID == 17 )    pSW = &(pMM->xSW[7]);
    if ( iID == 18 )    pSW = &(pMM->xSW[8]);


    pSW->iActionType = iType;

    pRule = &(pSW->R[pSW->nRule]);
    pSW->nRule++;

    if ( (iType == ACTION_DAY) || (iType == ACTION_TRIG) ) {
        iOn  = (iOn  / 100) * 3600 + (iOn  % 100) * 60;
        iOff = (iOff / 100) * 3600 + (iOff % 100) * 60;
    }

    if ( iType == ACTION_ALL ) {
        pRule->iValue           = iValue;
        pRule->iOnTime          = 0;
        pRule->iOffTime         = 0;
    }

    if ( iType == ACTION_DAY ) {
        pRule->iValue           = iValue;
        pRule->iOnTime          = iOn;
        pRule->iOffTime         = iOff;
    }

    if ( iType == ACTION_LOOP ) {
        pRule->iValue           = iValue;
        pRule->iOnTime          = i2 * 60;
        pRule->iOffValue        = i3;
        pRule->iOffTime         = i4 * 60;
        pRule->iOnOffDuration   = (i2 + i4) * 60;
    }

    if ( iType == ACTION_TRIG ) {
        pRule->iValue           = iValue;
        pRule->iOnTime          = iOn;
        pRule->iTrigSec         = i3;
    }

    if ( iType == ACTION_LOOPTRIG ) {
        pRule->iValue           = iValue;
        pRule->iOnTime          = i2 * 60;
        pRule->iTrigSec         = i3;
    }

    if ( iType == ACTION_MINMAX ) {
        pRule->iValue           = iValue;
        pRule->iMin             = i1;
        pRule->iLow             = i2;
        pRule->iHigh            = i3;
        pRule->iMax             = i4;
    }

    if ( iType == ACTION_LOOP ) {
        printf("  Loading SW%d [Type%d: %d(%d) %d(%d)]\n",
                 iID % 10, iType, i1, i2, i3, i4);
    }
    else
    if ( iType == ACTION_MINMAX ) {
        printf("  Loading SW%d [Type%d:_ (%d:%d:%d:%d)]\n",
                 iID % 10, iType, i1, i2, i3, i4);
    }
    else {
        printf("  Loading SW%d [Type%d:%d (%d,%d)]\n",
                 iID % 10, iType, iValue, iOn, iOff);
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     sio_LoadSensorRule(int iID, int iLoLimit, int iHiLimit)
{
    SEN*    pSEN  = NULL;
    RULE*   pRule = NULL;

    if ( iID == 31 )    pSEN = &(pMM->xSEN[1]);
    if ( iID == 32 )    pSEN = &(pMM->xSEN[2]);
    if ( iID == 33 )    pSEN = &(pMM->xSEN[3]);
    if ( iID == 34 )    pSEN = &(pMM->xSEN[4]);
    if ( iID == 35 )    pSEN = &(pMM->xSEN[5]);
    if ( iID == 36 )    pSEN = &(pMM->xSEN[6]);
    if ( iID == 37 )    pSEN = &(pMM->xSEN[7]);
    if ( iID == 38 )    pSEN = &(pMM->xSEN[8]);

    pSEN->iLoLimit      = iLoLimit;
    pSEN->iHiLimit      = iHiLimit;

    printf("  Loading SEN%d [Alarm:%d - %d]\n", iID % 10, iLoLimit, iHiLimit);

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Private Function
/// ------------------------------------------------------------------
int     convHHMM(int iVal)
{
    return ( ((iVal / 100) * 60 + (iVal % 100)) * 60 );
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_LoadLiveSwitchRule(int iDevID, int iType, int iTime, int* iaTime, int iError)
{
    SW*     pSW = NULL;

    pMM = &xMM;                 // Rewrite  (RPi compiler error ???)

    if ( iDevID == 11 )         pSW = &(pMM->xSW[1]);
    if ( iDevID == 12 )         pSW = &(pMM->xSW[2]);
    if ( iDevID == 13 )         pSW = &(pMM->xSW[3]);
    if ( iDevID == 14 )         pSW = &(pMM->xSW[4]);
    if ( iDevID == 15 )         pSW = &(pMM->xSW[5]);

    pSW->iActionType            = iType;
    pSW->iErrorRate             = iError;

    switch (iType) {
    case ACTION_ALL:
            pSW->nRule              = 1;

            {
                pSW->R[0].iValue        = iaTime[0];
                pSW->R[0].iOnTime       = 0;
                pSW->R[0].iOffTime      = 0;
                pSW->R[0].iOnOffDuration= 0;
                pSW->R[0].iError        = iError;

            /// pSW->R[0].iAction       = 0;
            /// pSW->R[0].iLastTrigTime = 0;
            }
            break;

    case ACTION_DAY:
            pSW->nRule              = iTime / 3;

            for ( int i = 0 ; i < iTime / 3 ; i++ ) {
                pSW->R[i].iValue        = iaTime[i*3 + 0];
                pSW->R[i].iOnTime       = convHHMM( iaTime[i*3 + 1] );
                pSW->R[i].iOffTime      = convHHMM( iaTime[i*3 + 2] );
                pSW->R[i].iOnOffDuration= 0;
                pSW->R[i].iError        = iError;
            }
            break;

    case ACTION_LOOP:
            pSW->nRule              = 1;

            {
                pSW->R[0].iValue        = iaTime[0];
                pSW->R[0].iOnTime       = iaTime[1] * 60;
                pSW->R[0].iOffValue     = iaTime[2];
                pSW->R[0].iOffTime      = iaTime[3] * 60;
                pSW->R[0].iOnOffDuration= iaTime[1] * 60 + iaTime[3] * 60;
                pSW->R[0].iError        = iError;
            }
            break;

    case ACTION_TRIG:
            pSW->nRule              = iTime / 3;

            for ( int i = 0 ; i < iTime / 3 ; i++ ) {
                pSW->R[i].iValue        = iaTime[i*3 + 0];
                pSW->R[i].iOnTime       = convHHMM( iaTime[i*3 + 1] );
                pSW->R[i].iTrigSec      = iaTime[i*3 + 2];
                pSW->R[i].iOnOffDuration= 0;
            }
            break;

    case ACTION_LOOPTRIG:
            pSW->nRule              = 1;

            {
                pSW->R[0].iValue        = iaTime[0];
                pSW->R[0].iOnTime       = iaTime[1] * 60;
                pSW->R[0].iTrigSec      = iaTime[2];
                pSW->R[0].iOnOffDuration= iaTime[1] * 60;
            }
            break;

    case ACTION_MINMAX:
            pSW->nRule              = 1;

            {
                pSW->R[0].iLow          = iaTime[0];
                pSW->R[0].iHigh         = iaTime[1];
                pSW->R[0].iMin          = iaTime[2];
                pSW->R[0].iMax          = iaTime[3];
            }
            break;
    }

#ifdef ARDUINO_ESP32
#else
    printf("  Update SW%d [Type%d:%d] [Err:%d]", iDevID, iType, iTime, iError);
    for ( int i = 0 ; i < iTime ; i++ ) {
        printf("%d ", iaTime[i]);
    }
    printf("\n");
#endif

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_LoadLiveSensorRule(int iDevID, int iLoLimit, int iHiLimit)
{
    SEN*    pSEN  = NULL;
    RULE*   pRule = NULL;

    if ( iDevID == 31 )         pSEN = &(pMM->xSEN[1]);
    if ( iDevID == 32 )         pSEN = &(pMM->xSEN[2]);
    if ( iDevID == 33 )         pSEN = &(pMM->xSEN[3]);
    if ( iDevID == 34 )         pSEN = &(pMM->xSEN[4]);
    if ( iDevID == 35 )         pSEN = &(pMM->xSEN[5]);
    if ( iDevID == 36 )         pSEN = &(pMM->xSEN[6]);
    if ( iDevID == 37 )         pSEN = &(pMM->xSEN[7]);
    if ( iDevID == 38 )         pSEN = &(pMM->xSEN[8]);

    pSEN->iLoLimit      = iLoLimit;
    pSEN->iHiLimit      = iHiLimit;

#ifdef ARDUINO_ESP32
#else
    printf("  Update SEN%d [Alarm:%d - %d]\n", iDevID % 10, iLoLimit, iHiLimit);
#endif

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
SW*     sio_FindSwitch(int iIndex)
{
    /*
    if ( iIndex < 8 )       return ( &(pMM->xAC[1 + iIndex-0]) );
    else                    return ( &(pMM->xDC[1 + iIndex-8]) );
    */

    return ( &(pMM->xSW[iIndex]) );
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     sio_UpdateSwitchOutput()
{
    SW*     pSW;
    RULE*   pRule;

    int     iCycle  = 0;
    int     iActionType;
    int     iOutVal;
    int     iTrig;

    int     iSecond = HAL_GetLocalTime();
    int     iMinute = iSecond / 60;

    for ( int i = 1 ; i <= MAX_SW ; i++ ) {
        pSW = sio_FindSwitch(i);

        iActionType = pSW->iActionType;

        if ( iActionType == ACTION_STOP ) {
            continue;
        }

        iOutVal = 0;

        for ( int j = 0 ; j < pSW->nRule ; j++ ) {
            pRule = &(pSW->R[j]);

            if ( iActionType == ACTION_ALL ) {
                iOutVal = pRule->iValue;
            }

            if ( iActionType == ACTION_DAY ) {
                if ( (pRule->iOnTime  <= iSecond) &&
                     (pRule->iOffTime >  iSecond) )     iOutVal = pRule->iValue;

                continue;   // Multiple Rule
            }

            if ( iActionType == ACTION_LOOP ) {
                if ( pRule->iOnOffDuration > 0 ) {
                    iCycle = iSecond % pRule->iOnOffDuration;
                }

                iOutVal = 0;
                if ( iCycle < pRule->iOnTime )          iOutVal = pRule->iValue;
            }

            if ( iActionType == ACTION_TRIG ) {
                iTrig = 0;
                if ( pRule->iOnTime == 0 )              iTrig = pRule->iValue;
                if ( (pRule->iOnTime / 60) == iMinute ) iTrig = pRule->iValue;

            /// if ( (iTrig > 0) && (pRule->iTrigOutSec == 0) ) {
                if ( (iTrig > 0) && (pRule->iTrigClearSec == 0) ) {
                    pRule->iTrigOutSec  = iSecond;
                    pRule->iTrigClearSec= iSecond + pRule->iTrigSec;
                    iOutVal = 1;
                }
                else
                if ( (pRule->iTrigOutSec > 0) && (iSecond < pRule->iTrigClearSec) ) {
                    iOutVal = 1;
                }
                else
                {
                    pRule->iTrigOutSec  = 0;
                /// pRule->iTrigClearSec= 0;
                }

                if ( (pRule->iOnTime / 60) != iMinute ) pRule->iTrigClearSec = 0;

                continue;   // Multiple Rule
            }

            if ( iActionType == ACTION_LOOPTRIG ) {
                if ( pRule->iOnOffDuration > 0 ) {
                    iCycle = iSecond % pRule->iOnOffDuration;
                }

                iTrig = 0;
                if ( iCycle / 60 == 0 )                 iTrig = pRule->iValue;

            /// if ( (iTrig > 0) && (pRule->iTrigOutSec == 0) ) {
                if ( (iTrig > 0) && (pRule->iTrigClearSec == 0) ) {
                    pRule->iTrigOutSec  = iSecond + pRule->iTrigSec;
                    pRule->iTrigClearSec= iSecond + pRule->iTrigSec + 60;
                    iOutVal = 1;
                }
                else
                if ( (pRule->iTrigOutSec > 0) && (iSecond > pRule->iTrigOutSec) ) {
                    pRule->iTrigOutSec = 0;
                    iOutVal = 0;
                }
                else
                if ( (pRule->iTrigClearSec > 0) && (iSecond > pRule->iTrigClearSec) ) {
                    pRule->iTrigClearSec = 0;
                }
            }

            if ( iActionType >= 10 ) {
                // Custom Type : Do Nothing
            }

            break;      // Default is Single Rule
        }

        pSW->iOutVal = iOutVal;

        if ( pSW->pSEN != NULL ) {
            pSW->pSEN->iOutVal = iOutVal;
        }
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     sio_UpdateSwitchTest()
{
    static  int     bInit = TRUE;


    if ( bInit == TRUE ) {
        bInit = FALSE;

        pMM->xSW[1].iOutVal = TRUE;
    }

    pMM->xSW[0].iOutVal = pMM->xSW[8].iOutVal;

    for ( int i = 8 ; i > 0 ; i-- ) {
        pMM->xSW[i].iOutVal = pMM->xSW[i-1].iOutVal;
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_UpdateSwitchRule(int bTest)
{
    if ( bTest == TRUE )    sio_UpdateSwitchTest();
    else                    sio_UpdateSwitchOutput();

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   SIO_WriteSwitchAll(int bTest)
{
    static  char    sLog[256];

    int     i;
    int     j;

    sLog[0] = '[';
    j = 0;

    for ( int i = 1 ; i <= MAX_SW ; i++ ) {
        SW*     pSW = sio_FindSwitch(i);

        if ( pSW->iDeviceType == SW_RELAY ) SIO_WriteSwitch(i, pSW->iOutVal);

        sLog[++j] = (pSW->iOutVal == 0) ? '.' : 'O';
    }

    sLog[++j] = ']';
    sLog[++j] = 0;

    return(sLog);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_WriteSwitch(int iIndex, int bOn)
{
    int     bOut = 0;

#ifdef USE_SWBOX
    switch (iIndex) {
    case 0  :       iIndex = DO_SW_RELAY1;      break;
    case 1  :       iIndex = DO_SW_RELAY2;      break;
    case 2  :       iIndex = DO_SW_RELAY3;      break;
    case 3  :       iIndex = DO_SW_RELAY4;      break;
    case 4  :       iIndex = DO_SW_RELAY5;      break;
    case 5  :       iIndex = DO_SW_RELAY6;      break;
    case 6  :       iIndex = DO_SW_RELAY7;      break;
    case 7  :       iIndex = DO_SW_RELAY8;      break;
    }
#endif

    return ( HAL_WriteGPIO(iIndex, bOut) );
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_UpdateSensor(SEN* pSEN, int iValue)
{
    int     iMove = (SEN_READ_HIST - 1) * sizeof(int);

    memmove( pSEN->aiRead + 1, pSEN->aiRead, iMove );

    pSEN->aiRead[0] = iValue;

    if ( pSEN->nRead < SEN_READ_HIST )  pSEN->nRead++;

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_CheckAlarmAll(int bTest)
{
    int     bAlarm = FALSE;
    SEN*    pSEN;

    for ( int i = 1 ; i < SEN_ARRAY ; i++ ) {
        pSEN = &(pMM->xSEN[i]);

        if ( pSEN->iDeviceType == 0 )   continue;

        if ( pSEN->aiRead[0] <= pSEN->iLoLimit )    bAlarm = TRUE;
        if ( pSEN->aiRead[0] >= pSEN->iHiLimit )    bAlarm = TRUE;

        if ( pSEN->bUseFeedBack == TRUE ) {
            if ( pSEN->aiRead[0] != pSEN->iOutVal )     bAlarm = TRUE;
        }
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_CheckAlarm(char** rpAlarmType, char** rpMessage)
{
    static  char    sAlarm[1024];

    int     bAlarm = FALSE;
    SEN*    pSEN;

    for ( int i = 1 ; i < SEN_ARRAY ; i++ ) {
        pSEN = &(pMM->xSEN[i]);

        if ( pSEN->iDeviceType == 0 )   continue;

        if ( pSEN->aiRead[0] <= pSEN->iLoLimit )    bAlarm = TRUE;
        if ( pSEN->aiRead[0] >= pSEN->iHiLimit )    bAlarm = TRUE;
    }

    if ( bAlarm == TRUE ) {
        *rpAlarmType = "WARNING";
        *rpMessage   = sAlarm;
    }
    else {
        *rpAlarmType = "INFO";
        *rpMessage   = "Normal Operation";
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_ReadCOM()
{
    int     iLen = 0;
    char    cChar;

    for ( ; ; ) {
    /// iLen = HAL_ReadCOM(pMM->sCOM, pMM->iCOM);
        iLen = HAL_ReadCOM(0, &cChar, 1);

        if ( (iLen == 0) )      return (FALSE); // Not Terminated

        if ( (iLen == 0) && (cChar == '\n') )   continue;
        if ( (iLen == 0) && (cChar == '\r') )   continue;

        if ( (iLen >  0) && (cChar == '\n') )   return (TRUE);
        if ( (iLen >  0) && (cChar == '\r') )   return (TRUE);

        // Load char in buffer
        pMM->sCOM[pMM->iCOM++] = cChar;
        pMM->sCOM[pMM->iCOM]   = 0;
    }

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_WriteCOM()
{
    HAL_WriteCOM(0, pMM->sCOM, pMM->iCOM);

    return (TRUE);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_ReadModbus(int bDebug, char* pBuffer, int iBuffer, char* pLog)
{
    int     iRead;

    if ( m_bUART_mux != UART_MUX_MODBUS ) {
        m_bUART_mux = UART_MUX_MODBUS;

        HAL_WriteGPIO(SVC_UART_SEL0, 0);
        HAL_WriteGPIO(SVC_UART_SEL1, 0);
    }

    memset(pBuffer, 0x33, iBuffer);

    iRead = HAL_ReadCOM(MODBUS_COM, pBuffer, iBuffer);

    if ( bDebug == TRUE ) {
        pLog += sprintf(pLog, "MODBUS RX is [%02x] ", iRead);

        for ( int i = 0 ; i < iRead + 0 ; i++ ) {
            if ( i == 2 )               pLog += sprintf(pLog, "| ");    // ID
            if ( i == (iRead - 2) )     pLog += sprintf(pLog, "+ ");    // CRC

            pLog += sprintf(pLog, "%02x ", (UCHAR)(pBuffer[i]));
        }
        pLog += sprintf(pLog, "\n");
    }

    return (iRead);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_WriteModbus(int bDebug, char* pBuffer, int iBuffer, char* pLog)
{
    if ( m_bUART_mux != UART_MUX_MODBUS ) {
        m_bUART_mux = UART_MUX_MODBUS;

        HAL_WriteGPIO(SVC_UART_SEL0, 0);
        HAL_WriteGPIO(SVC_UART_SEL1, 0);
    }

    HAL_WriteCOM(MODBUS_COM, pBuffer, iBuffer);

    if ( bDebug == TRUE ) {
        pLog += sprintf(pLog, "MODBUS TX is [%02x] ", iBuffer);

        for ( int i = 0 ; i < iBuffer + 0 ; i++ ) {
            if ( i == 2 )               pLog += sprintf(pLog, "| ");    // ID
            if ( i == (iBuffer - 2) )   pLog += sprintf(pLog, "+ ");    // CRC

            pLog += sprintf(pLog, "%02x ", (UCHAR)(pBuffer[i]));
        }
        pLog += sprintf(pLog, "\n");
    }

    return (iBuffer);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_ReadLTE(int bDebug, char* pBuffer, int iBuffer, char* pLog)
{
    int     iRead;

    if ( m_bUART_mux != UART_MUX_LTE ) {
        m_bUART_mux = UART_MUX_LTE;

        HAL_WriteGPIO(SVC_UART_SEL0, 1);
        HAL_WriteGPIO(SVC_UART_SEL1, 0);
    }

    memset(pBuffer, 0x33, iBuffer);

    iRead = HAL_ReadCOM(MODBUS_COM, pBuffer, iBuffer);

    if ( bDebug == TRUE ) {
        pLog += sprintf(pLog, "LTE RX is [%02x] ", iRead);

        pBuffer[iRead] = 0;
        pLog += sprintf(pLog, "%s\n", pBuffer);
    }

    return (iRead);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_WriteLTE(int bDebug, char* pBuffer, int iBuffer, char* pLog)
{
    if ( m_bUART_mux != UART_MUX_LTE ) {
        m_bUART_mux = UART_MUX_LTE;

        HAL_WriteGPIO(SVC_UART_SEL0, 1);
        HAL_WriteGPIO(SVC_UART_SEL1, 0);
    }

    HAL_WriteCOM(MODBUS_COM, pBuffer, iBuffer);

    if ( bDebug == TRUE ) {
        pLog += sprintf(pLog, "LTE TX is [%02x] ", iBuffer);

        pBuffer[iBuffer] = 0;
        pLog += sprintf(pLog, "%s\n", pBuffer);
    }

    return (iBuffer);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_ReadFIFO(int hFIFO, char* pBuffer)
{
    return ( HAL_ReadFIFO(hFIFO, pBuffer, FIFO_LEN) );
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
int     SIO_WriteFIFO(int hFIFO, char* pBuffer, int iLength)
{
    return ( HAL_WriteFIFO(hFIFO, pBuffer, iLength) );
}
