/*********************************************************************
    nio.c (Rev 0.90)

    SwitchBox Network Module

    Copyright(C)

    Programmed by  Stellar Respree
*********************************************************************/

#include "global.h"
#include "local.h"
#include "nio.h"


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   NIO_GetVersion()
{
    return ((char*)SWBOX_VERSION);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   NIO_GetSerial()
{
    return ((char*)SWBOX_SERIAL);
}


static  char    sAddr[16];
static  char    sMask[16];
static  char    sGate[16];
/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   NIO_GetNetworkIP()      { NIO_GetNetwork(NULL); return (sAddr); }
char*   NIO_GetNetworkMask()    { NIO_GetNetwork(NULL); return (sMask); }
char*   NIO_GetGatewayIP()      { NIO_GetNetwork(NULL); return (sGate); }


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   NIO_GetNetwork(char* pIfName)
{
    struct  ifaddrs *ifaddr, *ifa;

    static  int     bBoot = TRUE;
    static  char    sIFname[16] = {0};
    static  char    sNetwork[1024];

    UINT    uAddr = 0;
    UINT    uMask = 0;
    UINT    uMbit = 0;

    if ( (pIfName == NULL) && (bBoot == FALSE) )        return (sNetwork);

    if ( (pIfName == NULL) ) {
        pIfName = (char*)NIO_IF_NAME;
    }

    bBoot   = FALSE;

    strcpy(sAddr, "0.0.0.0");
    strcpy(sMask, "0.0.0.0");
    strcpy(sGate, "0.0.0.0");

    while (TRUE) {
        if ( getifaddrs(&ifaddr) == -1 )        break;

        for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) {
            if ( strcmp(ifa->ifa_name, pIfName) != 0 )  continue;
            if ( ifa->ifa_addr == NULL )                continue;
            if ( ifa->ifa_addr->sa_family != AF_INET )  continue;

        /// getnameinfo(ifa->ifa_addr,   sizeof(struct sockaddr_in), sAddr, NI_MAXHOST, NULL, 0, NI_NUMERICHOST);
        /// getnameinfo(ifa->ifa_netmask,sizeof(struct sockaddr_in), sMask, NI_MAXHOST, NULL, 0, NI_NUMERICHOST);

            uAddr = *(UINT*)(ifa->ifa_addr->sa_data + 2);
            uMask = *(UINT*)(ifa->ifa_netmask->sa_data + 2);

            {
                UINT    u = uMask;

                uMbit = 0;
                for ( int i = 0 ; i < 32 ; i++ ) {
                    if (u > 0)  uMbit++;
                    u /= 2;
                }
            }

        /// break;
        }

        freeifaddrs(ifaddr);

        break;
    }

    sprintf(sAddr, "%d.%d.%d.%d", (uAddr & 0xff), ((uAddr>>8) & 0xff), ((uAddr>>16) & 0xff), ((uAddr>>24) & 0xff));
    sprintf(sMask, "%d.%d.%d.%d", (uMask & 0xff), ((uMask>>8) & 0xff), ((uMask>>16) & 0xff), ((uMask>>24) & 0xff));

    {
        FILE*   f = fopen("/proc/net/route", "r");
        char    sHead[256];
        char    sLine[256];
        char*   pSeek;
        int     i1, i2, i3, i4;

        sprintf(sHead, "%s\t00000000", pIfName);

        while ( !feof(f) ) {
            fgets(sLine, 250, f);
            if ( strncmp(sLine, sHead, strlen(sHead)) == 0 ) {
                strcpy(sLine, sLine + strlen(sHead));
                pSeek = strtok(sLine, " \t");

                i4  = (pSeek[0] >= 'A') ? pSeek[0] - 'A' + 10 : pSeek[0] - '0';
                i4 *= 16;
                i4 += (pSeek[1] >= 'A') ? pSeek[1] - 'A' + 10 : pSeek[1] - '0';

                i3  = (pSeek[2] >= 'A') ? pSeek[2] - 'A' + 10 : pSeek[2] - '0';
                i3 *= 16;
                i3 += (pSeek[3] >= 'A') ? pSeek[3] - 'A' + 10 : pSeek[3] - '0';

                i2  = (pSeek[4] >= 'A') ? pSeek[4] - 'A' + 10 : pSeek[4] - '0';
                i2 *= 16;
                i2 += (pSeek[5] >= 'A') ? pSeek[5] - 'A' + 10 : pSeek[5] - '0';

                i1  = (pSeek[6] >= 'A') ? pSeek[6] - 'A' + 10 : pSeek[6] - '0';
                i1 *= 16;
                i1 += (pSeek[7] >= 'A') ? pSeek[7] - 'A' + 10 : pSeek[7] - '0';

                sprintf(sGate, "%d.%d.%d.%d", i1, i2, i3, i4);

                break;
            }
        }

        fclose(f);
    }

    sprintf(sNetwork, "%s/%s/%s", sAddr, sMask, sGate);

    return (sNetwork);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   NIO_GetMacAddress(char* pIfName)
{
static  char    sMAC[256];

    FILE*   f;
    char    sFile[256];

    sprintf(sFile, "/sys/class/net/%s/address", pIfName);

    f = fopen(sFile, "r");
    fscanf(f, "%s", sMAC);
    fclose(f);

    return (sMAC);
}


/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
char*   NIO_GetSSID(char* pIfName)
{
static  char    sSSID[256];

    FILE*   f;
    char    sFile[1024];
    char    sData[1024];
    char*   p;

/// sprintf(sFile, "wpa_cli -i %s status", pIfName);
/// sprintf(sFile, "iwlist %s scan", pIfName);
    sprintf(sFile, "iwgetid %s", pIfName);

    f = popen(sFile, "r");

    while ( fgets(sData, 1024, f) ) {
    /// if ( !strncmp(sData, "ssid", 4) )   break;
        if ( strstr(sData,  "ESSID:") )     break;
    };

    p = strstr(sData, "ESSID:");
    p = strtok(sData, "\"=\r\n");
    p = strtok(NULL,  "\"=\r\n");

    if ( p == NULL )    p = "(EMPTY)";
    strcpy(sSSID, p);

    return (sSSID);
}


#define DHCPCD_CONF     "/home/pi/res/dhcpcd.conf"
#define DHCPCD_CON0     "/home/pi/res/dhcpcd.conf0"
#define FACTORY_IPADDR  "990.990.990.990"
/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
/*
    sudo ifconfig eth0 192.168.10.5 netmask 255.255.255.0 up
    sudo route add default gw 192.168.10.1
*/
int     NIO_UpdateIP(char* pIP)
{
    char*   p1;
    char*   p2;
    char*   p3;

    int     iSeek = 0;
    char    c;

    printf("    SIO_UpdateIP : %s\n", pIP);

    {
        if ( pIP == NULL )              goto ERROR;

        p1 = strtok(pIP,  "/\r\n");
        p2 = strtok(NULL, "/\r\n");
        p3 = strtok(NULL, "/\r\n");

        if ( p1 == NULL )               goto ERROR;
        if ( p2 == NULL )               goto ERROR;
        if ( p3 == NULL )               goto ERROR;
printf("p1 %s\n", p1);
printf("p2 %s\n", p2);
printf("p3 %s\n", p3);
    }

    {
        FILE*   f;
        FILE*   g;
        char    sLine[256];

        f = fopen(DHCPCD_CON0, "r");
        g = fopen(DHCPCD_CONF, "w");

        while ( !feof(f) ) {
            fgets(sLine, 250, f);
            fputs(sLine, g);
        }

        if ( !strcmp(p1, FACTORY_IPADDR) ) {        // Add Custom Setting
            p1 = (char*)NIO_DEFAULT_IP;
            p3 = (char*)NIO_DEFAULT_GW;
        }

        sprintf(sLine, "static ip_address=%s/24\n", p1);
        fputs(sLine, g);

        sprintf(sLine, "static routers=%s\n", p3);
        fputs(sLine, g);

        fclose(f);
        fclose(g);
    }

    NIO_Reboot((char*)"1234qwer");

    return (TRUE);

ERROR:
    return (FALSE);
}


#define REBOOT_PASSWORD         "1234qwer"
/// ------------------------------------------------------------------
/// Interface Function
/// ------------------------------------------------------------------
void    NIO_Reboot(char* pPass)
{
    printf("    SIO_Reboot : %s\n", pPass);

    if ( !strcmp(pPass, REBOOT_PASSWORD) ) {
    //  sync();
    //  reboot(RB_AUTOBOOT);
        system(NIO_REBOOT_SH);

        printf("    Check Root Privilege\n");
    }
    else {
        printf("    Reboot Password Mismatch\n");
    }
}
