/*********************************************************************
    CRC.h (Rev 0.90)

    CRC Processing Module

    Copyright(C) 2020  MemoryLab Ltd.

    Programmed by  Stellar Respree
*********************************************************************/

#ifndef __CRC_H__
#define __CRC_H__

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_CRC                 50


int     CRC_InitPoly(int iHandle, int iPoly, int iBitSize);
int     CRC_Calc(int iHandle, char* pSource, int iSource);
int     CRC_CalcEx(int iHandle, char* pSource, int iSource, int iInitVal, int bSrcRev, int bOutRev);

#ifdef __cplusplus
}
#endif

#endif

