/*********************************************************************
    uNATS.h  (Rev 0.10)

    Micro NATS Library

    Programmed by Stellar Respree

    Copyright(C) MemoryLab Ltd.
*********************************************************************/

//--------------------------------------------------------------------
//  Global Definition
//--------------------------------------------------------------------
#define NACMD_PING              80
#define NACMD_PONG              81

#define NACMD_OK                1
#define NACMD_INFO              2
#define NACMD_CONNECT           3
#define NACMD_SUB               4
#define NACMD_PUB_LOGIN         5
#define NACMD_MSG               6
#define NACMD_MSG_ADDGROUP      7
#define NACMD_MSG_DELGROUP      8

#define NACMD_PUB_STATUS        10
#define NACMD_PUB_MONITOR       11
#define NACMD_PUB_ALARM         12


//--------------------------------------------------------------------
//  API Function
//--------------------------------------------------------------------
int     NATS_Init(void* pMM, int hLog);

int     NATS_Connect(char* pServerAddr, int iPort);
int     NATS_Disconnect();

int     NATS_ReadInfo();
int     NATS_Read();
int     NATS_Send(int iNACMD);

