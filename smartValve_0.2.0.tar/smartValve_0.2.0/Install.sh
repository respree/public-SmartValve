wget https://raw.githubusercontent.com/respree/public-SmartValve/main/smartvalve$1.tar.gz
tar -xf smartValve$1.tar.gz
rm -f smartValve
ln -s smartValve$1 smartValve
